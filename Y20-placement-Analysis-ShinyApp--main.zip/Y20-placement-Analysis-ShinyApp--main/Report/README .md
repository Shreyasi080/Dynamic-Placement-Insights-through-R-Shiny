# Report

Your final report and supporting docs


Again, you will need to set working directory

```r
setwd("/path/to/mth-208-course-project-group24/Report")

```

