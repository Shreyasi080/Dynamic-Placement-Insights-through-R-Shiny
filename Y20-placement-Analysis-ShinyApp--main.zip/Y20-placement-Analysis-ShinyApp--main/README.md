# Y20-placement-Analysis
The stucture of this directory is as follows:

├── app.R (The main app) 

├── companies.Rdata (Company Data)

├── new_students.Rdata (Student Data)

├── README.md

└── students_correlated.csv (Mapping column for student and company data)

